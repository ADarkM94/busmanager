<?php $__env->startSection('title'); ?>
    Giới thiệu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<!-- Giới thiệu -->
	    <div class="maingioithieu">
	        <div class="trangtentintuc"><h2>Giới Thiệu</h2></div>
	        <div style="margin-top: 4em;">
	        <?php $__currentLoopData = $gioithieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $t->noidung; ?>

	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    	</div>
	    </div>
	<!-- Kết thúc phần giới thiệu -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tttn-web.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>