<?php $__env->startSection('title'); ?>
	<?php if(isset($ttxe)): ?>
		Chỉnh sửa thông tin xe
	<?php else: ?>
		Thêm xe
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .row > *:nth-child(2) {
            text-align: left;
        }
		.header .row > *:nth-child(2) {
            text-align: center;
        }
    </style>
    <div class="content show row" id="addxe">
        <div class="col-lg-3">
            <?php if(session('alert')): ?>
                <div class="modal fade" id="alertmessage">
					<div class="modal-dialog" style="width: 400px; margin-top: 200px;">
						<div class="modal-content" style="text-align: center;">
							<div class="modal-header">
								<div class="modal-title">Thông báo</div>
							</div>
							<div class="modal-body alert alert-warning" style="text-align: center; margin-bottom: 0;">
								<?php echo e(session('alert')); ?>

							</div>
							<div class="modal-footer" style="text-align: center;">
								<span class="btn btn-success" data-dismiss="modal">OK</span>
							</div>
						</div>
					</div>
				</div>
				<script>
					$(document).ready(function(){
						$('#alertmessage').modal('show');
					});
				</script>
            <?php endif; ?>
        </div>
        <form name="ttxe" class="col-lg-6" action="<?php echo e(route('addbus')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <fieldset>
                <legend><?php echo isset($ttxe)? 'Sửa Thông Tin Xe':'Thêm Xe';?></legend>
                <?php if(isset($ttxe)): ?>
                    <?php
                    $ttxe = (array)$ttxe;
                    ?>
                    <input type="hidden" name="ID" value="<?php echo e($ttxe['Mã']); ?>">
                <?php endif; ?>
                <label>Biển số</label>
                <input type="text" class="form-control" name="bienso" value="<?php echo e(isset($ttxe['Biển_số'])? $ttxe['Biển_số']:''); ?>" placeholder="Biển số xe">
                <br>
                <label>Loại xe</label>
                <select class="form-control" name="idtypebus">
                    <?php $__currentLoopData = $bustypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bustype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $bustype = (array)$bustype;?>
                        <option value="<?php echo e($bustype['Mã']); ?>" <?php echo e(isset($ttxe['Mã_loại_xe'])? ($bustype['Mã']==$ttxe['Mã_loại_xe']? 'selected':''):''); ?>><?php echo e($bustype['Tên_Loại']); ?>-<?php echo e($bustype['Loại_ghế']==0? 'Ghế_ngồi':'Giường_nằm'); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <label>Lần bảo trì gần nhất</label>
                <br>
                <input type="date" class="form-control" name="baotrigannhat" value="<?php echo e(isset($ttxe['Ngày_bảo_trì_gần_nhất'])? $ttxe['Ngày_bảo_trì_gần_nhất']:''); ?>">
                <br>
                <label>Lần bảo trì tiếp theo</label>
                <br>
                <input type="date" class="form-control" name="baotritieptheo" value="<?php echo e(isset($ttxe['Ngày_bảo_trì_tiếp_theo'])? $ttxe['Ngày_bảo_trì_tiếp_theo']:''); ?>">
                <br>
                <div style="text-align: center">
                    <input type="submit" class="btn btn-success" value="<?php echo isset($ttxe)? 'Sửa Thông Tin':'Thêm Xe';?>">
                    <input type="button" onclick="location.assign('<?php echo e(url('/admin/xe')); ?>')" class="btn btn-danger" value="Hủy">
                </div>
            </fieldset>
        </form>
        <div class="col-lg-3"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('excontent'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        option = document.getElementsByClassName("option");
        for (var i = 0; i < option.length; i++) {
            option[i].classList.remove('selected');
        }
        option[7].classList.add('selected');
        option[7].getElementsByTagName('img')[0].setAttribute('src','<?php echo e(asset("images/icons/bus-hover.png")); ?>');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('quantrivien.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>