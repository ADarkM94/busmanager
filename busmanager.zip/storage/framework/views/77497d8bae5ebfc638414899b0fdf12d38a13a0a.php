<?php if(Auth::check()): ?>
    <h4>Tên người dùng: <?php echo $user['Nickname']; ?></h4>
    <a href="<?php echo e(route('logout')); ?>">Đăng xuất</a>
<?php else: ?>
    <form action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" class="form-control" name="username" placeholder="Tên đăng nhập">
        <input type="password" class="form-control" name="password" placeholder="Mật khẩu">
        <input type="submit" class="form-control" name="login" value="Đăng Nhập">
    </form>
<?php endif; ?>
