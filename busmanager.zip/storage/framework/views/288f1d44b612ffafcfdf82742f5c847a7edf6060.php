<?php $__env->startSection('title'); ?>
    Tin tức
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <!-- Trang tin tức --> 
    <div class="maintintuc">
        <div class="trangtintuc">
            <div class="trangtentintuc"><h2>Tin Tức</h2></div>
            <ul>
                <ul>
              <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php  $id = $y->news_id; ?>
                    <img src="upload/<?php echo e($y->image); ?>">
                    
                    <a href="<?php echo e(asset("showtintuc/{$id}")); ?>"><strong><?php echo e($y->title); ?></strong></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </ul>
            </ul>
        </div>
        <div style="clear: left;"></div>
          <!-- Phân trang --> 
        <ul class="pager">
           <?php echo $tintuc->links(); ?>

        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tttn-web.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>