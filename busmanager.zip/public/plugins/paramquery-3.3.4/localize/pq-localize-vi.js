/**
 * Created by THANHHUYEN on 12/01/2016.
 */

jQuery.paramquery.pqGrid.regional['vi'] = {
    strAdd: "Thêm",
    strDelete: "Xóa",
    strEdit: "Sửa",
    strLoading: "Đang tải dữ liệu...",
    strNextResult: "Kết quả kế tiếp",
    strNoRows: "Không có dữ liệu.",
    strNothingFound: "Không có dữ liệu.",
    strPrevResult: "Kết quả trước đó",
    strSearch: "Tìm kiếm",
    strSelectedmatches: "Đang chọn {0} trong tổng số {1} dòng."
};
jQuery.paramquery.pqPager.regional['vi']={
    strDisplay:"Đang xem {0} đến {1} trong tổng số {2}.",
    strFirstPage:"Đầu",
    strLastPage:"Cuối",
    strNextPage:"Tiếp",
    strPage:"Trang {0} của {1}",
    strPrevPage:"Trước",
    strRefresh:"Tải lại",
    strRpp:"Số dòng trên một trang:{0}"
};