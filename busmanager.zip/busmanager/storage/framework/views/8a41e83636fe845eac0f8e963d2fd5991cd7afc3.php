<?php $__env->startSection('content'); ?>
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('excontent'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        option = document.getElementsByClassName("option");
        for (var i = 0; i < option.length; i++) {
            option[i].classList.remove('selected');
        }
        option[2].classList.add('selected');
        option[2].getElementsByTagName('img')[0].setAttribute('src','<?php echo e(asset("images/icons/chuyenxe-hover.png")); ?>');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('quantrivien.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>