<?php $__env->startSection('title'); ?>
    Giới thiệu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="maingioithieu">
        <div class="tentintuc"><h2>Giới Thiệu</h2></div>
        <div style="margin-top: 4em;">
            <p>Là một trong những công ty hàng đầu trong lĩnh vực xe khách đường dài.</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tttn-web.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>