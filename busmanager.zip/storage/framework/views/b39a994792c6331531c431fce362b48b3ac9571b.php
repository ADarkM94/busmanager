<!DOCTYPE html>
<html>
<head></head>
<body>
<style>
    table {
        border: 1px solid black;
    }
    th,td {
        border: 1px solid black;
    }
</style>
<?php if(isset($matrix)): ?>
    <table>
        <?php $__currentLoopData = $matrix; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($key); ?></th>
                <?php for($i=0;$i<count($value);$i++): ?>
                    <td><?php echo e($value[$i]); ?></td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>
<?php if(isset($normmatrix)): ?>
    <table>
        <?php $__currentLoopData = $normmatrix; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($key); ?></th>
                <?php for($i=0;$i<count($value);$i++): ?>
                    <td><?php echo e($value[$i]); ?></td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>
<?php if(isset($similarmatrix)): ?>
    <table>
        <?php $__currentLoopData = $similarmatrix; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($key); ?></th>
                <?php for($i=0;$i<count($value);$i++): ?>
                    <td><?php echo e($value[$i]); ?></td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>
<?php if(isset($normmatrixFull)): ?>
    <table>
        <?php $__currentLoopData = $normmatrixFull; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($key); ?></th>
                <?php for($i=0;$i<count($value);$i++): ?>
                    <td><?php echo e($value[$i]); ?></td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>
<?php if(isset($matrixFinal)): ?>
    <table>
        <?php $__currentLoopData = $matrixFinal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($key); ?></th>
                <?php for($i=0;$i<count($value);$i++): ?>
                    <td><?php echo e($value[$i]); ?></td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php endif; ?>
</body>
</html>
