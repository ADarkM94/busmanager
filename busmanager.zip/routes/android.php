<?php
/* Bắt đầu phần route cho App Android */

//Code route cho app android trong này

/* Kết thúc phần route cho App Android */
