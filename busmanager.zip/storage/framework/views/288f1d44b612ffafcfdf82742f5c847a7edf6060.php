<?php $__env->startSection('title'); ?>
    Tin tức
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="maintintuc">
        <div class="trangtintuc">
            <div class="trangtentintuc"><h2>Tin Tức</h2></div>
            <ul>
                <li>
                    <img src="images/12.jpg">
                    <a><strong>CHUYỂN TUYẾN HẢI PHÒNG ↔ HỒ CHÍ MINH, VŨNG TÀU VỀ BẾN THƯỢNG LÝ - HẢI PHÒNG TỪ 22/11/2017</strong></a>
                </li>
                <li>
                    <img src="images/12.jpg">
                    <a><strong>CHUYỂN TUYẾN HẢI PHÒNG ↔ HỒ CHÍ MINH, VŨNG TÀU VỀ BẾN THƯỢNG LÝ - HẢI PHÒNG TỪ 22/11/2017</strong></a>
                </li>

                <li>
                    <img src="images/12.jpg">
                    <a><strong>CHUYỂN TUYẾN HẢI PHÒNG ↔ HỒ CHÍ MINH, VŨNG TÀU VỀ BẾN THƯỢNG LÝ - HẢI PHÒNG TỪ 22/11/2017</strong></a>
                </li>

                <li>
                    <img src="images/12.jpg">
                    <a><strong>CHUYỂN TUYẾN HẢI PHÒNG ↔ HỒ CHÍ MINH, VŨNG TÀU VỀ BẾN THƯỢNG LÝ - HẢI PHÒNG TỪ 22/11/2017</strong></a>
                </li>

                <li>
                    <img src="images/12.jpg">
                    <a><strong>CHUYỂN TUYẾN HẢI PHÒNG ↔ HỒ CHÍ MINH, VŨNG TÀU VỀ BẾN THƯỢNG LÝ - HẢI PHÒNG TỪ 22/11/2017</strong></a>
                </li>
                <li>
                    <img src="images/12.jpg">
                    <a><strong>CHUYỂN TUYẾN HẢI PHÒNG ↔ HỒ CHÍ MINH, VŨNG TÀU VỀ BẾN THƯỢNG LÝ - HẢI PHÒNG TỪ 22/11/2017</strong></a>
                </li>
            </ul>
        </div>
        <ul class="pager">
            <li><a href="tintuc">Previous</a></li>
            <li><a href="tintuc">1</a></li>
            <li><a href="tintuc">2</a></li>
            <li><a href="tintuc">3</a></li>
            <li><a href="tintuc">4</a></li>
            <li><a href="tintuc">5</a></li>
            <li><a href="tintuc">Next</a></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tttn-web.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>