<?php $__env->startSection('title'); ?>
    Đặt vé
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="buoc">
        <ul>
            <li style="background: #f57812; color: #FFF;" class="stay">Tìm Chuyến</li>
            <li>Chọn Chuyến</li>
            <li>Chi Tiết Vé</li>
        </ul>
    </div>
    <div class="maindatve">
         <form name="timve" action="<?php echo e(route('chuyenxe1')); ?>" method="POST">
         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <ul>
            <li>
                <div class="diadiemdatve">
                    <label>Chọn Nơi Khởi Hành </label>
                    <div class="the">
                        <i class="fa fa-bus"></i>
                        <select name="Noidi">
                        <?php $__currentLoopData = $tinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($t->Tên); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="chonloaixe">
                        <p>Chọn loại xe</p>
                        <form>
                            <input checked="checked" name="Giuong" type="radio" value="1" />Giường nằm
                            <br>
                            <input type="radio" name="Giuong" value="0" />Ghế ngồi
                        </form>
                    </div>
                </div>
            </li>
            <li>
                <div class="diadiemdatve">
                    <label>Chọn Nơi Đến </label>
                    <div class="the">
                        <i class="fa fa-bus"></i>
                        <select name="Noiden">
                        <?php $__currentLoopData = $tinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($t->Tên); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                    </div>
                </div>
            </li>
            <li>
                <div class="ngaydidatve">
                    <label>Chọn Thời Gian đi </label>
                    <div class="form-group" style="width: 350px;">
                        <div class='input-group date' style="box-shadow: 0 3px #F3AD45; ">
                            <span class="input-group-addon" style="background: #FFF; border: none;">
                            <span class="glyphicon glyphicon-calendar" style="color: #f57812;"></span>
                            </span>
                            <input type='date' class="form-control" style="border: none;" name="Ngaydi" id="txtdate" />
                        </div>
                     </div>
                    <div class="tim">
                        <i class="fa fa-ticket icon-flat bg-btn-actived"></i>
                         <button type="button" class="btn" onclick="document.forms['timve'].submit();"><a href="javascript:void(0)" >Tìm vé</a></button>
                    </div>
                </div>
            </li>
        </ul>
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        function chonngay(){
            var d = new Date();
            var ngay = d.getDate()<10? ('0'+d.getDate()):d.getDate();
            var thang = d.getMonth() + 1 <10? ('0'+d.getMonth()+1):d.getMonth()+1;
            var nam = d.getFullYear();
            document.getElementById("txtdate").min=nam+"-"+thang+"-"+ngay;
            document.getElementById("txtdate").value= nam+"-"+thang+"-"+ngay;
        }
        chonngay();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tttn-web.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>