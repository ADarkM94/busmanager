<?php $__env->startSection('content'); ?>
    <div class="content bando show">
        <span onclick="showMap()">Hiển thị bản đồ</span>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('excontent'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function showMap(){
            var mapOptions = {
                center: new google.maps.LatLng(51.2, 46),
                zoom: 10,
                mapTypeId: google.maps.MapTypeId.HYBRID
            };
            var map = new google.maps.Map(document.getElementsByClassName("bando")[0],mapOptions);
        }
        option = document.getElementsByClassName("option");
        for (var i = 0; i < 2; i++) {
            option[i].classList.remove('selected');
        }
        option[0].classList.add('selected');
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDPoe4NcaI69_-eBqxW9Of05dHNF0cRJ78&callback=showMap"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('quanlydatve.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>