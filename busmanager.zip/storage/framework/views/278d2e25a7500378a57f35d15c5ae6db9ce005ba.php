<?php $__env->startSection('title'); ?>
    Chuyến xe
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- phần bước -->
        <div class="buoc">
            <ul>
                <li>Tìm Chuyến</li>
                <li class="stay">Chọn Chuyến</li>
                <li>Chi Tiết Vé</li>
            </ul>
        </div>
    <!-- kết thức phần bước -->
    <!-- Phần chuyến xe  -->
        <div class="chuyenxemain">
            <table>
                <tr>
                    <th>Mã chuyến</th>
                    <th>Tuyến</th>
                    <th>Giờ Xuất Bến</th>
                    <th>Thời Gian Đến</th>
                    <th>Loại Xe</th>
                    <th>Giá</th>
                    <th>Đặt Mua</th>
                </tr>
                <?php $__currentLoopData = $Chuyenxe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($t->Mã); ?></td>
                        <td><span><?php echo e($t->Nơi_đi); ?> -> <?php echo e($t->Nơi_đến); ?></span></td>
                        <td><span><?php echo e($t->Ngày_xuất_phát); ?> : <?php echo e($t->Giờ_xuất_phát); ?></span></td>
                        <td><span><?php echo e($t->Thời_gian_đến_dự_kiến); ?></span></td>
                        <td><span><?php echo e(($t->Loại_ghế==1)? 'Giường Nằm':'Ghế Ngồi'); ?></span></td>
                        <td><span><?php echo e(($t->Tiền_vé)/1000); ?>.000 VNĐ</span></td>
                        <td><div class="chuyenxetim">
                                <?php if(Session::has('makh')): ?>
                                    <i class="fa fa-arrow-right icon-flat bg-btn-actived"></i>
                                    <button type="button" class="btn"><a href="chonve/<?php echo e($id=$t->Mã); ?>">Đặt vé</a></button>
                                <?php else: ?>
                                    <i class="fa fa-arrow-right icon-flat bg-btn-actived"></i>
                                    <button type="button" class="btn"><a data-toggle="modal" data-target="#login" data-dismiss="modal" >Đặt vé</a></button>
                                <?php endif; ?>
                            </div></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <!-- Kết thúc phần chuyến xe  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tttn-web.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>