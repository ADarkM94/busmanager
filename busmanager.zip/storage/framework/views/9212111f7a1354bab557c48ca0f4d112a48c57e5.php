<?php $__env->startSection('title'); ?>
    Chọn vé
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <script>
        $(function(){
          $('td[onload]').trigger('onload');
        });
    </script>
    <div class="buoc">
        <ul>
            <li>Tìm Chuyến</li>
            <li>Chọn Vé</li>
            <li style="background: #f57812; color: #FFF;" class="stay">Chi Tiếc vé</li>
        </ul>
    </div>
    
<!-- chu ý-->
    <div class="chonvemain">
        <div class="chonveleft">
            <?php $__currentLoopData = $chonve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3>Thông tin vé</h3>
            <p><i class="fa fa-bus"></i> Nơi Khởi Hành: <a><?php echo e($t->Nơi_đi); ?></a></p><br>
            <p><i class="fa fa-bus"></i> Nơi đến: <a><?php echo e($t->Nơi_đến); ?></a></p> <br>
            <p><span class="glyphicon glyphicon-time"></span> Ngày đi: <?php echo e($t->Ngày_xuất_phát); ?>  <?php echo e($t->Giờ_xuất_phát); ?></p><br>
            <p><span class="glyphicon glyphicon-bed"></span> Loại Ghế: <?php echo e(($t->Loại_ghế==1)? 'Giường Nằm':'Ghế Ngồi'); ?> </p><br>
            <p><i class="fa fa-balance-scale"></i> Giá vé: <?php echo e($t->Tiền_vé/1000); ?>.000 VNĐ</p><br>
            <p><i class="fa fa-address-card-o"></i> Vé đang chọn: </p><br>
            <button type="button" style="background: #f57812; border: none;" class="btn btn-success chondatve"  data-id=<?php echo e($id); ?>>Đặt vé</button>
        </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="chonveright">
            <?php if($sodo[0]->Loại_ghế == 1): ?>
            <div class="tengiuong"><h3>Sơ đồ xe</h3></div>
            <div class="chuygiuong">
                <ul>
                <li><i class="loaighetrong"></i> &nbsp;Còn trống</li>
                <li><i class="loaighechon"></i> &nbsp;Đang chọn</li>
                <li><i class="loaigheban"></i> &nbsp;Đã bán</li>
                <li><i class="loaighecochon"></i> &nbsp;Có Người Chọn</li>
                <li><buttontype="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#chonloaidexuat" style="background: #f57812; border: none;" title="Đề xuất vị trí">Đề xuất</button></li>
            </ul>
            </div>
                <?php  $sd = $sodo[0]->Sơ_đồ; $dem=0; ?>
                 <div class="sodogiuong">
                 <table class="bangve tangduoi">
                  <tr>
                      <td class="giuongtaixe" title="Ghế tài xế"></td>
                      <td colspan="4"></td>
                   </tr>
                    <?php for($i=1;$i<7;$i++): ?>
                    <tr>
                       <?php for($j=0;$j<5;$j++): ?>
                            <?php if($sd[$i * 5 + $j]==1): ?>
                                <?php if($ve[$dem]->Trạng_thái == 1): ?>
                                <td class="giuong" title="Giường đã bán cho khách"><div class="contentgiuong"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>
                                <?php elseif($ve[$dem]->Trạng_thái ==0): ?>
                                <td class="giuongcontrong" title="Ghế trống" data-ma=<?php echo e($ve[$dem]->Mã); ?>>
                                    <div class="contentgiuong"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>
                                <?php elseif($ve[$dem]->Trạng_thái == 2): ?>
                                    <?php if($ve[$dem]->Mã_khách_hàng == Session::get('makh')): ?>
                                        <td class="giuongdangchon" title="Ghế Đang Chọn" data-ma=<?php echo e($ve[$dem]->Mã); ?>></div><div class="contentgiuong"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>

                                    <?php else: ?>
                                         <td class="giuongcochon" title="Đã Có Người Chọn" data-ma=<?php echo e($ve[$dem]->Mã); ?>></div><div class="contentgiuong"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>

                                    <?php endif; ?>
                                <?php endif; ?>
                                  <?php  $dem++; ?>
                            <?php else: ?>
                                <td class="giuongtrong"></td>
                            <?php endif; ?>
                       <?php endfor; ?>
                    </tr>
                    <?php endfor; ?>
                </table>
                <table class="bangve tangtren">
                  <tr>
                    <td class="giuongtaixe" title="Ghế tài xế">
                    </td>
                    <td colspan="4"></td>
                  </tr>
                    <?php for($i=7;$i<13;$i++): ?>
                    <tr>
                       <?php for($j=0;$j<5;$j++): ?>
                            <?php if($sd[$i * 5 + $j]==1): ?>
                                <?php if($ve[$dem]->Trạng_thái == 1): ?>
                                <td class="giuong" title="Giường đã bán cho khách"></div><div class="contentgiuong"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>
                                <?php elseif($ve[$dem]->Trạng_thái ==0): ?>
                                <td class="giuongcontrong" title="Ghế trống" data-ma=<?php echo e($ve[$dem]->Mã); ?>>
                                    <div class="contentgiuong"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>
                                <?php elseif($ve[$dem]->Trạng_thái == 2): ?>
                                    <?php if($ve[$dem]->Mã_khách_hàng == Session::get('makh')): ?>
                                        <td class="giuongdangchon" title="Ghế Đang Chọn" data-ma=<?php echo e($ve[$dem]->Mã); ?>></div><div class="contentgiuong"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>

                                    <?php else: ?>
                                         <td class="giuongcochon" title="Đã Có Người Chọn" data-ma=<?php echo e($ve[$dem]->Mã); ?>></div><div class="contentgiuong"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>

                                    <?php endif; ?>
                                <?php endif; ?>
                                  <?php  $dem++; ?>
                            <?php else: ?>
                                <td class="giuongtrong"></td>
                            <?php endif; ?>
                       <?php endfor; ?>
                    </tr>
                    <?php endfor; ?>
            </table>
            <div class="tang">
                <button class="duoi">Tầng Dưới</button>
                <button class="tren">Tầng Trên</button>
            </div>
             </div>
              
               <?php else: ?>
                <div class="tengiuong"><h3>Sơ đồ xe</h3></div>
                <div class="chuygiuong">
                    <ul>
                    <li><i class="loaighetrong"></i> &nbsp;Còn trống</li>
                    <li><i class="loaighechon"></i> &nbsp;Đang chọn</li>
                    <li><i class="loaigheban"></i> &nbsp;Đã bán</li>
                    <li><i class="loaighecochon"></i> &nbsp;Có Người Chọn</li>
                    <li><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#chonloaidexuat" style="background: #f57812;border: none;" title="Đề xuất vị trí">Đề xuất</button></li>
                </ul>
                </div>
               <div class="sodoghe">
               <table class="bangve">
                    <?php  $sd = $sodo[0]->Sơ_đồ; $dem=0; ?>
                    <?php for($i=0;$i<12;$i++): ?>
                    <tr>
                        <?php for($j=0;$j<6;$j++): ?>
                            <?php if($sd[$i * 6 + $j]==1 && ($i * 6 + $j)==0): ?>
                                <td class="ghetaixe" title="Ghế tài xế">
                                  <img src="../images/ghetaixe2.png">
                                </td>
                            <?php elseif($sd[$i * 6 + $j] == 1): ?>
                                <?php if($ve[$dem]->Trạng_thái == 1): ?>
                                <td class="ghe" title="Ghế đã bán cho khách" data-ma=<?php echo e($ve[$dem]->Mã); ?> />
                                    <img src="../images/ghe.png"/>
                                     
                                    <div class="content"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>
                                <?php elseif($ve[$dem]->Trạng_thái ==0): ?>
                                    <td class="ghecontrong" title="Ghế trống" data-ma=<?php echo e($ve[$dem]->Mã); ?>><img src="../images/ghe.png">
                                      <input class="text1" type="text" readonly="readonly">
                                        <div class="content"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>
                                <?php elseif($ve[$dem]->Trạng_thái == 2): ?>
                                    <?php if($ve[$dem]->Mã_khách_hàng == Session::get('makh')): ?>
                                        <td class="ghedangchon" title="Ghế Đang Chọn" onload="demnguoc2(<?php echo e($ve[$dem]->Mã); ?>,<?php echo e($ve[$dem]->TG); ?>)" data-ma=<?php echo e($ve[$dem]->Mã); ?>><img src="../images/ghe.png">
                                           <input class="text1" type="text"  readonly="readonly"><div class="content"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>

                                    <?php else: ?>
                                         <td class="ghecochon" title="Đã Có Người Chọn" onload="demnguoc1(<?php echo e($ve[$dem]->Mã); ?>,<?php echo e($ve[$dem]->TG); ?>)" data-ma=<?php echo e($ve[$dem]->Mã); ?>><img src="../images/ghe.png">
                                           <input class="text1"  type="text"  readonly="readonly"><div class="content"><?php echo e($ve[$dem]->Vị_trí_ghế); ?></div></td>

                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php $dem++; ?>
                            <?php else: ?>
                                <td class="ghetrong"></td>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </tr>
                    <?php endfor; ?>
               <?php endif; ?>
            </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('excontent'); ?>
  <div id="vedexuat" class="modal fade" role="dialog">
    <div class="modal-dialog" style="width: 400px;">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Vé Được Đề Xuất</h4>
      </div>
      <div class="modal-body">
        <div style="text-align: center;" >
          <h4 style="background: #f57812; text-align: center; color: #FFF; height: 40px; line-height: 40px; border-radius: 0.5em;">Vé Tốt Nhất</h4>
          <div class="vetotnhat"></div>
        </div>
        <div style="text-align: center;">
          <h4 style="background: #f57812; text-align: center; color: #FFF; height: 40px; line-height: 40px; border-radius: 0.5em;">Các Vé Tiếp Theo</h4>
          <div class="vetieptheo"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
    <div id="chonloaidexuat" class="modal fade" role="dialog">
        <div class="modal-dialog" style="width:400px;">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h3 class="modal-title">Bạn muốn mua vé cho ai ?</h3>
            </div>
            <div class="modal-body" style="margin-left: 20%;">
                <button type="button" class="btn dxchominh" onclick="$(body).css('padding-right','0');"  data-dismiss="modal" data-toggle="modal" data-target="#vedexuat" style="background: #f57812; color: #FFF; height: 50px;">Cho Mình</button>
                 <button type="button" class="btn dxnguoithan" onclick="$(body).css('padding-right','0');"  data-dismiss="modal" data-toggle="modal" data-target="#dexuatchonguoithan" style="background: #f57812;color: #FFF; height: 50px; margin-left: 30px;">Người Thân</button>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
          </div>

        </div>
    </div>
    <div id="dexuatchonguoithan" class="modal fade" role="dialog">
        <div class="modal-dialog" style="width:400px;">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h3 class="modal-title">Nhập thông tin người thân !</h3>
            </div>
            <div class="modal-body">
                <div class="input-group">
                  <span class="input-group-addon" style="background: #f57812; border: none; width: 100px; color: #FFF; height: 34px;">Giới Tính</span>
                   <label class="checkbox-inline" style="margin-top: 7px;">
                        <input type="radio" name="txtgioitinh" value="1" checked>Nam
                  </label>
                  <label class="checkbox-inline" style="margin-top: 7px;"> 
                        <input type="radio" name="txtgioitinh" value="2">Nữ
                  </label>
                </div>
                <br>
                <div class="input-group">
                  <span class="input-group-addon" style="background: #f57812; border: none; width: 100px; color: #FFF;  height: 33px;">Độ Tuổi</span>
                  <input type="number" style="width: 116px; height: 33px;" class="txttuoi" placeholder="....(tuổi)">
                  <span class="input-group-addon" style="background: #f57812; border: none;color: #FFF;height: 34px;"><i class="fa fa-arrow-right"></i></span>
                  <input type="number" style="width: 116px; height: 33px;" class="txttuoi2" placeholder="....(tuổi)">
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn chondxnguoithan" onclick="$(body).css('padding-right','0');" data-dismiss="modal" style="background: #f57812; color: #FFF;">Đề xuất</button>
              <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
            </div>
          </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        mang=[];
        function myfunction(){
          alert("ticketsuggestionaasa");
        }
        function demnguoc(ma,thoigian){
            thoigian = thoigian -1;
            if(thoigian !=-1){
             $("td[data-ma='"+ma+"'] .text1").val(thoigian + "s");
              setTimeout("demnguoc("+ma+","+thoigian+")",1000);
            }
            else{
              $("td[data-ma='"+ma+"'] .text1").hide();
              
            }
        }
        function demnguoc1(ma,thoigian){
           $("td[data-ma='"+ma+"'] .text1").show();
          ma = $("td[data-ma='"+ma+"']").attr("data-ma");
            thoigian = thoigian -1;
            if(thoigian !=-1){
             $("td[data-ma='"+ma+"'] .text1").val(thoigian + "s");
              setTimeout("demnguoc1("+ma+","+thoigian+")",1000);
            }
            else{
              $("td[data-ma='"+ma+"'] .text1").hide();
                $("td[data-ma='"+ma+"']").addClass("ghecontrong");
                $("td[data-ma='"+ma+"']").removeClass("ghecochon");

            }
        }
         function demnguoc2(ma,thoigian){
          $("td[data-ma='"+ma+"'] .text1").show();
          ma = $("td[data-ma='"+ma+"']").attr("data-ma");
            thoigian = thoigian -1;
            if(thoigian !=-1){
             $("td[data-ma='"+ma+"'] .text1").val(thoigian + "s");
              setTimeout("demnguoc1("+ma+","+thoigian+")",1000);
            }
            else{
              $("td[data-ma='"+ma+"'] .text1").hide();
                $("td[data-ma='"+ma+"']").addClass("ghecontrong");
                $("td[data-ma='"+ma+"']").removeClass("ghedangchon");

            }
        }
        function datghe(bien,ma){
            makh = <?php echo e(Session::get('makh')); ?>;
                 bien.addClass("ghedangchon");
                 bien.removeClass("ghecontrong");
                 mang.push(ma);
                  $("td[data-ma='"+ma+"'] .text1").show();
                 demnguoc(ma,600);
                $.ajax({
                    url: '<?php echo e(route("xulydatve")); ?>',
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        MA: ma,
                        MAKH: makh
                    },
                    success: function (data) {
                       if(data.kq == 0){
                        bien.addClass("ghecontrong");
                        bien.removeClass("ghedangchon");
                        for (i=0; i < mang.length; i++) {
                           if(mang[i]==ma){
                                mang[i]=null;
                                break;
                           }
                       }
                       }
                       else if(data.kq==1){
                        bien.addClass("ghe");
                        bien.removeClass("ghedangchon");
                        demnguoc(ma,200);
                        for (i=0; i < mang.length; i++) {
                           if(mang[i]==ma){
                                mang[i]=null;
                                break;
                           }
                       }
                        alert("Xin lổi - Ghế này đã có người mua !")
                       }
                       else if(data.kq == 2){
                        bien.addClass("ghecochon");
                        bien.removeClass("ghedangchon");
                        demnguoc(ma,200);
                        for (i=0; i < mang.length; i++) {
                           if(mang[i]==ma){
                                mang[i]=null;
                                break;
                           }
                       }
                        alert("Xin lổi - Ghế này đã có người chọn !")
                       }
                    }
             });
        }
        function datgiuong(bien,ma){
          makh = <?php echo e(Session::get('makh')); ?>;
                        bien.addClass("giuongdangchon");
                        bien.removeClass("giuongcontrong");
                        mang.push(ma);
                $.ajax({
                    url: '<?php echo e(route("xulydatve")); ?>',
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        MA: ma,
                        MAKH: makh
                    },
                    success: function (data) {
                      if(data.kq==0){
                        bien.addClass("giuongcontrong");
                        bien.removeClass("giuongdangchon");
                        for (i=0; i < mang.length; i++) {
                           if(mang[i]==ma){
                                mang[i]=null;
                                break;
                           }
                       }
                      }
                       else if(data.kq==1){
                        bien.addClass("giuong");
                        bien.removeClass("giuongdangchon");
                        for (i=0; i < mang.length; i++) {
                           if(mang[i]==ma){
                                mang[i]=null;
                                break;
                           }
                       }
                        alert("Xin lổi - Ghế này đã có người mua !")
                       }
                       else if(data.kq == 2){
                        bien.addClass("giuongcochon");
                        bien.removeClass("giuongdangchon");
                        for (i=0; i < mang.length; i++) {
                           if(mang[i]==ma){
                                mang[i]=null;
                                break;
                           }
                       }
                        alert("Xin lổi - Ghế này đã có người chọn !")
                       }
                    }
             });
        }
        $(document).ready(function(){
         $(".bangve").delegate(".ghecontrong","click",function(){
                ma = $(this).attr("data-ma");
                bien = $(this);
                datghe(bien,ma);
            });
          $(".bangve").delegate(".ghedangchon","click",function(){
                ma = $(this).attr("data-ma");
                bien = $(this);
                $.ajax({
                    url: '<?php echo e(route("xulydatve2")); ?>',
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        MA: ma,
                    },
                    success: function (data) {
                       if(data.kq == 1){
                        bien.addClass("ghecontrong");
                        bien.removeClass("ghedangchon");
                        $("td[data-ma='"+ma+"'] .text1").hide();
                       for (i=0; i < mang.length; i++) {
                           if(mang[i]==ma){
                                mang[i]=null;
                                break;
                           }
                       }
                       }
                    }
             });
        });
                $(".bangve").delegate(".giuongcontrong","click",function(){
                ma = $(this).attr("data-ma");
                bien = $(this);
                datgiuong(bien,ma);
                
            });
               $(".bangve").delegate(".giuongdangchon","click",function(){
                ma = $(this).attr("data-ma");
                bien = $(this);
                $.ajax({
                    url: '<?php echo e(route("xulydatve2")); ?>',
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        MA: ma,
                    },
                    success: function (data) {
                       if(data.kq == 1){
                        bien.addClass("giuongcontrong");
                        bien.removeClass("giuongdangchon");
                       for (i=0; i < mang.length; i++) {
                           if(mang[i]==ma){
                                mang[i]=null;
                                break;
                           }
                       }
                       }
                    }
             });
        });
               $(".chondatve").click(function(){
                    id = $(this).attr("data-id");
                    makh =<?php echo e(Session::get('makh')); ?>;
                    dodai = mang.length;
                    $.ajax({
                        url: '<?php echo e(route("chondatve")); ?>',
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        ID: id,
                        MANG:mang,
                        MAKH:makh,
                        DODAI:dodai
                    },
                    success: function (data) {
                       location.assign("<?php echo e(asset('thongtinve')); ?>/"+id+"/"+makh);
                    }
                    });
               });
               $(".tren").click(function(){
                    $(".tren").css({"background":"#f57812","color":"#FFF"});
                    $(".duoi").css({"background":"#CCC","color":"#000"});
                    $(".tangtren").show();
                    $(".tangduoi").hide();
               });
               $(".duoi").click(function(){
                $(".duoi").css({"background":"#f57812","color":"#FFF"});
                $(".tren").css({"background":"#CCC","color":"#000"});
                $(".tangduoi").show();
                $(".tangtren").hide();
               });
              $(".dxchominh").click(function () {
                   makh = '<?php echo e(session('makh')); ?>';
                   machuyenxe = '<?php echo e($chonve[0]->Mã); ?>';
                  $.ajax({
                      url: '<?php echo e(route('ticketsuggestion')); ?>',
                      data: {
                          _token: '<?php echo e(csrf_token()); ?>',
                          idkhachhang: makh,
                          idchuyenxe: machuyenxe
                      },
                      type: 'post',
                      success: function (data) {
                        dem = data.kq.length;
                        vitri = data.kq[0].Vị_trí_ghế;
                        $(".vetotnhat").html(vitri);
                        for(i=1;i<6;i++){
                          vitri = data.kq[i].Vị_trí_ghế;
                          $(".vetieptheo").after(vitri);
                           $(".vetieptheo").after("<br>");
                        }
                      }
                  }) ;
               });
               $(".chondxnguoithan").click(function () {
                   machuyenxe = '<?php echo e($chonve[0]->Mã); ?>';
                   var kt = true;
                   var gioitinh = document.getElementsByName("txtgioitinh");
                    for (var i = 0; i < gioitinh.length; i++){
                    if (gioitinh[i].checked === true){
                       gt = gioitinh[i].value;
                    }
                  }
                  var tuoi = $(".txttuoi").val();
                  var tuoi2 = $(".txttuoi2").val();
                 $.ajax({
                      url: '<?php echo e(route('ticketsuggestion')); ?>',
                      data: {
                          _token: '<?php echo e(csrf_token()); ?>',
                          gioitinh: gt,
                          idchuyenxe: machuyenxe,
                          tuoimin: tuoi,
                          tuoimax: tuoi2
                      },
                      type: 'post',
                      success: function (data) {
                        if(data.kq == 0){
                          alert("dasdasdasdasd");
                        }
                        else{
                          alert('Trang web đề nghị cho bạn những ghế sau:\n'+data.kq[0].Vị_trí_ghế);
                        }
                      }
                  }) ;
               });
});
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tttn-web.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>