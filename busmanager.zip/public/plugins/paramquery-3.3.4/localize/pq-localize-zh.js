/**
 * @author pdhindsa
 */
jQuery.paramquery.pqGrid.regional['zh'] = {
    strLoading: "加载",
    strAdd: "加",
    strEdit: "编辑",
    strDelete: "删除",
    strSearch: "搜索",
    strNothingFound: "",
    strSelectedmatches:"选择{0}{1}匹配",
    strPrevResult: "上一结果",
    strNextResult: "",
    strNoRows: "没有行显示"        
};
jQuery.paramquery.pqPager.regional['zh']={
    strPage:"第 {0} 页（共 {1} 页）",
    strFirstPage:"第一页",
    strPrevPage:"上一页",
    strNextPage:"下一页",
    strLastPage:"尾页",
    strRefresh:"刷新",	
    strRpp:"每页记录: {0}",
    strDisplay:"显示 {0} 到 {1} {2} 个项目"	
};
